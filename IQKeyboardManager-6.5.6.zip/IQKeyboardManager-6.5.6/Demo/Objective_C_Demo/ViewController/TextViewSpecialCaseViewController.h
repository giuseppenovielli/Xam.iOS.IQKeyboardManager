//
//  TextViewSpecialCaseViewController.h
//  KeyboardTextFieldDemo

#import <UIKit/UIKit.h>

@interface TextViewSpecialCaseViewController : UIViewController
{
    IBOutlet UIButton *buttonPush;
    IBOutlet UIButton *buttonPresent;
}

- (IBAction)presentClicked:(id)sender;

@end
