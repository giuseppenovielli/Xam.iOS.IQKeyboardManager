//
//  ImageSwitchTableViewCell.h
//  Demo
//
//  Created by IEMacBook01 on 22/05/16.
//  Copyright © 2016 Iftekhar. All rights reserved.
//

#import "SwitchTableViewCell.h"

@interface ImageSwitchTableViewCell : SwitchTableViewCell

@property(nonatomic, strong) IBOutlet UIImageView *arrowImageView;

@end
