//
//  OptionTableViewCell.m
//  IQKeyboard
//
//  Created by Iftekhar on 27/09/14.
//  Copyright (c) 2014 Iftekhar. All rights reserved.
//

#import "OptionTableViewCell.h"

@implementation OptionTableViewCell
@synthesize labelOption;

- (void)awakeFromNib
{
    [super awakeFromNib];
}

@end
