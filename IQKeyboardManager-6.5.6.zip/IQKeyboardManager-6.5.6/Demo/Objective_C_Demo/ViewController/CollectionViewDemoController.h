//
//  CollectionViewDemoController.h
//  IQKeyboard
//
//  Created by Iftekhar on 29/10/14.
//  Copyright (c) 2014 Iftekhar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionViewDemoController : UIViewController

@end
